import React,{useState} from 'react';
import { Text, View, StyleSheet,FlatList,TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {

  const [people,setPeople]=useState([
    {name:'serhat',id:1},{name:'serpil',id:2},
    {name:"murat",id:3},{name:'selim',key:4},
    {name:'serhat',id:5},{name:'serpil',id:6},
    {name:"murat",id:7},{name:'selim',id:8},
      {name:'serhat',id:9},{name:'serpil',id:10},
    {name:"murat",id:11},{name:'selim',id:12},
    {name:'serhat',id:13},{name:'serpil',id:14},
    {name:"murat",id:15},{name:'selim',id:16},
      {name:'serhat',id:1},{name:'serpil',id:2},
    {name:"murat",id:17},{name:'selim',id:18},
    {name:'serhat',key:19},{name:'serpil',id:20},
    {name:"murat",id:21},{name:'selim',id:22},
  ]);

const pressHandler=(id)=>{
  setPeople((prevPeople)=>{
    return prevPeople.filter(person=>person.id!=id);
  });

  }


  return (
    <View style={styles.container}>
     <FlatList
     keyExtractor={(item)=>item.id}
     numColumns={2}
 data={people}
 renderItem={({item})=>(
   <TouchableOpacity onPress={()=>pressHandler(item.id)}>
    <Text style={styles.name}>name is {item.name}</Text>
   </TouchableOpacity>
  
 )}
     />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  name:{

    fontSize:25,
    margin:5,backgroundColor:'orange',
    padding:10,
  borderRadius:40
    
  }
});
